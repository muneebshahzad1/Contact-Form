
<!DOCTYPE html>
<html>
<head>
  <title> Contact Form </title>
  <style>
  body {
   background-image: url("11.jpg");
    background-repeat: no-repeat;
  background-size: 100%;
}

p {
  text-align: center;
  text-transform: uppercase;
  color:#1a1a00;
  font-size: 180%;
  font-weight: bold;
  opacity: 0.8;
text-shadow: 2px 2px 5px blueviolet;
}
input[type=submit] {
  background-color:ghostwhite;
  color:black;
  padding: 17px 33px;
  text-decoration: none;
  margin: 5px 3px;
  cursor: pointer;
  opacity:0.6;
}
</style>
  </head>
<body>
  <form action="index1.php" method="post">
<p align='center'>Contact Form</p>


<label for="fname" style="text-shadow: 2px 2px 5px blueviolet"><b>Full Name*</b></label><br>
  <input type="text" name="fname" style="width: 1300px; height: 30px; opacity: 0.7;" placeholder="Enter Your Full Name">
  <br>
  <br>
  <br>


  <label for="email" style="text-shadow: 2px 2px 5px blueviolet"><b>E-Mail*</b></label><br>
  <input type="text" name="email" style="width: 1300px; height: 30px; opacity: 0.7;"  placeholder=" E-Mail Address">
  <br>
  <br>
  <br>

<label for="department" style="text-shadow: 2px 2px 5px blueviolet">&nbsp;&nbsp;<b>Department*</b></label><br>
 <input type="radio"  name="cs" value="Software Engineering">
 <label for="se" style="text-shadow: 2px 2px 5px blueviolet">Software Engineering</label><br>
 <input type="radio"  name="cs" value="Computer Science">
 <label for="cs" style="text-shadow: 2px 2px 5px blueviolet">Computer Science</label><br>
 <input type="radio" name="cs" value="Information Technology">
 <label for="it" style="text-shadow: 2px 2px 5px blueviolet">Information Technology</label><br><br>
  <br>

  <label for="contactreason" style="text-shadow: 2px 2px 5px blueviolet"><b>Contact Reason*</b></label><br>
  <input type="text" name="contactreason" style="width: 1300px; height: 30px; opacity: 0.7 "  placeholder=" Contact Reason">
  <br>
  <br>
  <br>

  <label for="msg" style="text-shadow: 2px 2px 5px blueviolet"><b>Message*</b></label><br>
  <input type="text" name="msg" style="width: 1300px; height: 70px; opacity: 0.7 " placeholder ="Write Message">
  <br>
  <br>
  <br>

<input type="submit" style="margin-left: 40%"value= "SEND MESSAGE">

</form>
</body>
</html>
