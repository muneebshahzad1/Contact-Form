<htmL>
<body>
    <style>
    body {
   background-image: url("19.jpg");
  background-repeat: no-repeat;
  background-size: 100%;
  opacity: 0.8;
}
table,td{ border: 3px solid  dark yellow;
  padding: 6px;}
#t01 {
  width: 50%; 
  height: 80%;   
  background-color: #b3cccc;
  opacity: 0.7;

}
</style>
<?php
 $a = $_POST["fname"];
 $b = $_POST["email"];
 $c = $_POST["contactreason"];
 $d = $_POST["msg"];
 $f = $_POST["cs"];

$arr = [$a, $b, $c, $d, $f];


echo "<table id=t01 border=3 cellspacing=7 cellpading=3 align=center>
<br>
<br>
<br>
<tr><td align=center>$arr[0]</td></tr>
<tr><td align=center>$arr[1]</td></tr>
<tr><td align=center>$arr[2]</td></tr>
<tr><td align=center>$arr[3]</td></tr>
<tr><td align=center>$arr[4]</td></tr>
</table>";
?>